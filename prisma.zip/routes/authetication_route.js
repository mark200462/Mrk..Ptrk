const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const bcrypt = require("bcrypt");

const saltrounds = 8;

module.exports = (app) => {

};
