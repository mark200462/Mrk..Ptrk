const dotenv = require("dotenv").config();
const cors = require("cors");
const express = require("express");
const app = express();
var bodyparser = require("body-parser");
const port = process.env.PORT;
const jsonnn = bodyparser.json()
app.use(
  cors({
    origin: "*",
  })
);
app.use(bodyparser.json());

require("./routes/authetication_route.js");

module.exports = app;

app.post("/api/register",jsonnn, async (req, res) => {
    try {
      var accountemail = await prisma.account.findFirst({
        where: { email: req.body.email },
      });
      console.log(req.body)
      const hash = await bcrypt.hash(req.body.password, saltRounds);
      console.log(accountemail)
      if (accountemail) {
        var newaccount = await prisma.account.create({
          data: {
            email: req.body.email,
            username: req.body.username,
            password: hash
          },
        });
        return res.json({ message: "Successful registration." , account: newaccount});
      }
      throw new Error('The request was bad!');
    } catch {
    }
  });


app.listen(port, () => {
  console.log("The server has started " + port);
});
